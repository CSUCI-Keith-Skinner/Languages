#include "person.h"

LIST *head = NULL, *tail = NULL;

void inputPersonalData(PERSON *person)
{
    // TODO Implement the function
}

void addPersonalDataToDatabase(PERSON *person)
{
    // TODO Implement the function
}

void displayDatabase()
{
    // TODO Implement the function
}

void displayPerson(PERSON *person)
{
    // TODO Implement the function
}

PERSON *findPersonInDatabase(char *name)
{
    // TODO Implement the function

    return NULL; // if not found
}

void removePersonFromDatabase(char *name)
{
    // TODO Implement the function
}

void clearDatabase()
{
    // TODO Implement the function
}
